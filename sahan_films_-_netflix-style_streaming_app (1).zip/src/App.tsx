import { useState } from "react";
import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { Toaster } from "sonner";
import LandingPage from "./components/LandingPage";
import Dashboard from "./components/Dashboard";
import MobileDashboard from "./components/MobileDashboard";
import ProfileSetup from "./components/ProfileSetup";
import AboutUs from "./components/AboutUs";
import Careers from "./components/Careers";
import Press from "./components/Press";
import Contact from "./components/Contact";
import HelpCenter from "./components/HelpCenter";
import Account from "./components/Account";
import PrivacyPolicy from "./components/PrivacyPolicy";
import TermsOfService from "./components/TermsOfService";
import CookiePolicy from "./components/CookiePolicy";

export default function App() {
  const [showSignUp, setShowSignUp] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [currentPage, setCurrentPage] = useState("home");
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const userProfile = useQuery(api.auth.getUserProfile);

  // Listen for window resize to detect mobile/desktop
  useState(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  });

  const handleGetStarted = (email: string) => {
    setUserEmail(email);
    setShowSignUp(true);
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleBack = () => {
    setCurrentPage("home");
  };

  if (loggedInUser === undefined || userProfile === undefined) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  // Render different pages based on currentPage state
  if (currentPage !== "home") {
    switch (currentPage) {
      case "about":
        return <AboutUs onBack={handleBack} />;
      case "careers":
        return <Careers onBack={handleBack} />;
      case "press":
        return <Press onBack={handleBack} />;
      case "contact":
        return <Contact onBack={handleBack} />;
      case "help":
        return <HelpCenter onBack={handleBack} />;
      case "account":
        return <Account onBack={handleBack} />;
      case "privacy":
        return <PrivacyPolicy onBack={handleBack} />;
      case "terms":
        return <TermsOfService onBack={handleBack} />;
      case "cookies":
        return <CookiePolicy onBack={handleBack} />;
      default:
        break;
    }
  }

  return (
    <div className="min-h-screen">
      <Authenticated>
        {!userProfile ? (
          <ProfileSetup onComplete={() => window.location.reload()} />
        ) : (
          // Use mobile dashboard for mobile devices, regular dashboard for desktop
          isMobile ? <MobileDashboard /> : <Dashboard />
        )}
      </Authenticated>
      
      <Unauthenticated>
        {showSignUp ? (
          <div className="min-h-screen bg-black flex items-center justify-center">
            <div className="w-full max-w-md mx-auto p-8">
              <div className="text-center mb-8">
                <h1 className="text-red-600 text-3xl font-bold mb-4">SAHAN FILMS</h1>
                <h2 className="text-white text-2xl font-semibold mb-2">Create your account</h2>
                <p className="text-gray-400">Join millions of viewers worldwide</p>
              </div>
              <SignInForm defaultEmail={userEmail} />
              <div className="text-center mt-6">
                <button 
                  onClick={() => setShowSignUp(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ← Back to homepage
                </button>
              </div>
            </div>
          </div>
        ) : (
          <LandingPage onGetStarted={handleGetStarted} onNavigate={handleNavigate} />
        )}
      </Unauthenticated>
      
      <Toaster />
    </div>
  );
}
