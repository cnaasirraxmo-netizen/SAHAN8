import { useState, useRef, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  Cog6ToothIcon, 
  UserCircleIcon,
  ChevronRightIcon,
  PlayIcon,
  HomeIcon,
  FilmIcon,
  CreditCardIcon,
  ArrowDownTrayIcon,
  MagnifyingGlassIcon,
  TvIcon,
  CheckIcon
} from "@heroicons/react/24/outline";
import { 
  HomeIcon as HomeIconSolid,
  FilmIcon as FilmIconSolid,
  CreditCardIcon as CreditCardIconSolid,
  ArrowDownTrayIcon as ArrowDownTrayIconSolid,
  MagnifyingGlassIcon as MagnifyingGlassIconSolid
} from "@heroicons/react/24/solid";
import VideoPlayer from "./VideoPlayer";
import MovieDetail from "./MovieDetail";
import { Id } from "../../convex/_generated/dataModel";

interface Movie {
  _id: Id<"movies">;
  title: string;
  description: string;
  genre: string;
  thumbnail: string;
  videoUrl: string;
  rating: number;
  year: number;
  duration: string;
  category: string;
  featured?: boolean;
}

type TabType = 'all' | 'movies' | 'tv-shows' | 'sports' | 'live-tv';
type NavType = 'home' | 'films' | 'subscriptions' | 'downloads' | 'search';

export default function MobileDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [activeNav, setActiveNav] = useState<NavType>('home');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [showMovieDetail, setShowMovieDetail] = useState(false);
  const [playingMovie, setPlayingMovie] = useState<Movie | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const featuredMovie = useQuery(api.movies.getFeaturedMovie);
  const trendingMovies = useQuery(api.movies.getMoviesByCategory, { category: "trending" });
  const actionMovies = useQuery(api.movies.getMoviesByCategory, { category: "action" });
  const somaliMovies = useQuery(api.movies.getMoviesByCategory, { category: "somali" });
  const documentaries = useQuery(api.movies.getMoviesByCategory, { category: "documentary" });
  const allMovies = useQuery(api.movies.getAllMovies);
  const searchResults = useQuery(api.movies.searchMovies, searchTerm ? { searchTerm } : "skip");

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setShowMovieDetail(true);
  };

  const handlePlayMovie = (movie: Movie) => {
    setPlayingMovie(movie);
    setShowMovieDetail(false);
  };

  const handleCloseDetail = () => {
    setShowMovieDetail(false);
    setSelectedMovie(null);
  };

  const handleClosePlayer = () => {
    setPlayingMovie(null);
  };

  // Show video player if a movie is playing
  if (playingMovie) {
    return (
      <VideoPlayer 
        movie={playingMovie} 
        onClose={handleClosePlayer}
      />
    );
  }

  // Show movie detail if selected
  if (showMovieDetail && selectedMovie) {
    return (
      <MovieDetail 
        movieId={selectedMovie._id}
        onClose={handleCloseDetail}
        onPlay={handlePlayMovie}
      />
    );
  }

  const ContentCarousel = ({ title, movies, showMore = true }: { title: string; movies: Movie[] | undefined; showMore?: boolean }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    if (!movies || movies.length === 0) return null;

    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3 px-4">
          <h3 className="text-white font-semibold text-lg">{title}</h3>
          {showMore && (
            <button className="flex items-center text-gray-400 text-sm">
              <span>More</span>
              <ChevronRightIcon className="w-4 h-4 ml-1" />
            </button>
          )}
        </div>
        <div 
          ref={scrollRef}
          className="flex space-x-3 overflow-x-auto scrollbar-hide px-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {movies.slice(0, 10).map((movie) => (
            <div 
              key={movie._id}
              className="flex-shrink-0 w-32 cursor-pointer"
              onClick={() => handleMovieClick(movie)}
            >
              <div className="relative group">
                <img 
                  src={movie.thumbnail} 
                  alt={movie.title}
                  className="w-full h-48 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-active:bg-opacity-30 transition-all duration-200 rounded-lg flex items-center justify-center">
                  <PlayIcon className="w-8 h-8 text-white opacity-0 group-active:opacity-100 transition-opacity duration-200" />
                </div>
              </div>
              <h4 className="text-white text-sm font-medium mt-2 line-clamp-2">{movie.title}</h4>
              <p className="text-gray-400 text-xs">{movie.year}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (activeNav) {
      case 'search':
        return (
          <div className="flex-1 bg-black">
            {/* Search Header */}
            <div className="p-4 border-b border-gray-800">
              <div className="relative">
                <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search movies, shows..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-gray-800 text-white pl-10 pr-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
                  autoFocus
                />
              </div>
            </div>

            {/* Search Results */}
            <div className="p-4">
              {searchTerm && searchResults ? (
                <div>
                  <h2 className="text-white text-xl font-bold mb-4">Search Results</h2>
                  <div className="grid grid-cols-2 gap-4">
                    {searchResults.map((movie) => (
                      <div 
                        key={movie._id}
                        className="cursor-pointer"
                        onClick={() => handleMovieClick(movie)}
                      >
                        <img 
                          src={movie.thumbnail} 
                          alt={movie.title}
                          className="w-full h-48 object-cover rounded-lg"
                        />
                        <h3 className="text-white font-medium mt-2 text-sm">{movie.title}</h3>
                        <p className="text-gray-400 text-xs">{movie.year} • {movie.genre}</p>
                      </div>
                    ))}
                  </div>
                  {searchResults.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      No results found for "{searchTerm}"
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <MagnifyingGlassIcon className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                  <p>Search for movies and shows</p>
                </div>
              )}
            </div>
          </div>
        );

      case 'films':
        return (
          <div className="flex-1 bg-black">
            <div className="p-4">
              <h2 className="text-white text-2xl font-bold mb-6">All Films</h2>
              <div className="grid grid-cols-2 gap-4">
                {allMovies?.map((movie) => (
                  <div 
                    key={movie._id}
                    className="cursor-pointer"
                    onClick={() => handleMovieClick(movie)}
                  >
                    <img 
                      src={movie.thumbnail} 
                      alt={movie.title}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <h3 className="text-white font-medium mt-2 text-sm">{movie.title}</h3>
                    <p className="text-gray-400 text-xs">{movie.year} • {movie.genre}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'subscriptions':
        return (
          <div className="flex-1 bg-black p-4">
            <h2 className="text-white text-2xl font-bold mb-6">Subscriptions</h2>
            <div className="space-y-4">
              <div className="bg-gray-900 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-semibold">SAHAN FILMS Premium</h3>
                  <span className="bg-green-600 text-white px-2 py-1 rounded text-xs">Active</span>
                </div>
                <p className="text-gray-400 text-sm mb-3">Unlimited streaming, 4K quality, offline downloads</p>
                <p className="text-white font-semibold">$17.99/month</p>
                <p className="text-gray-400 text-xs">Next billing: January 15, 2024</p>
              </div>
              
              <div className="bg-gray-900 rounded-lg p-4">
                <h3 className="text-white font-semibold mb-2">Manage Subscription</h3>
                <div className="space-y-2">
                  <button className="w-full text-left text-gray-300 py-2 border-b border-gray-700">
                    Change Plan
                  </button>
                  <button className="w-full text-left text-gray-300 py-2 border-b border-gray-700">
                    Payment Method
                  </button>
                  <button className="w-full text-left text-gray-300 py-2 border-b border-gray-700">
                    Billing History
                  </button>
                  <button className="w-full text-left text-red-400 py-2">
                    Cancel Subscription
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 'downloads':
        return (
          <div className="flex-1 bg-black p-4">
            <h2 className="text-white text-2xl font-bold mb-6">Downloads</h2>
            <div className="text-center py-12 text-gray-500">
              <ArrowDownTrayIcon className="w-16 h-16 mx-auto mb-4 text-gray-600" />
              <p className="mb-2">No downloads yet</p>
              <p className="text-sm">Download movies and shows to watch offline</p>
            </div>
          </div>
        );

      default: // home
        return (
          <div className="flex-1 bg-black">
            {/* Content Tabs */}
            <div className="flex space-x-6 px-4 py-3 border-b border-gray-800">
              {[
                { id: 'all', label: 'All' },
                { id: 'movies', label: 'Movies' },
                { id: 'tv-shows', label: 'TV shows' },
                { id: 'sports', label: 'Sports' },
                { id: 'live-tv', label: 'Live TV' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeTab === tab.id 
                      ? 'bg-white text-black' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Featured Content */}
            {featuredMovie && (
              <div className="relative h-64 mb-6">
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.8)), url(${featuredMovie.thumbnail})`
                  }}
                />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="mb-2">
                    <span className="text-red-600 text-sm font-semibold">SAHAN FILMS™</span>
                  </div>
                  <h2 className="text-white text-xl font-bold mb-2 leading-tight">
                    {featuredMovie.title.toUpperCase()}
                  </h2>
                  <div className="flex items-center mb-3">
                    <CheckIcon className="w-4 h-4 text-green-500 mr-2" />
                    <span className="text-green-500 text-sm">Included with SAHAN FILMS™</span>
                  </div>
                  <button 
                    onClick={() => handlePlayMovie(featuredMovie)}
                    className="bg-white text-black px-6 py-2 rounded-lg font-semibold flex items-center space-x-2"
                  >
                    <PlayIcon className="w-4 h-4" />
                    <span>Play</span>
                  </button>
                </div>
              </div>
            )}

            {/* Content Carousels */}
            <div className="pb-20">
              <ContentCarousel title="SAHAN FILMS™ movies" movies={somaliMovies} />
              <ContentCarousel title="SAHAN FILMS™ Originals" movies={trendingMovies} />
              <ContentCarousel title="Action Movies" movies={actionMovies} />
              <ContentCarousel title="Documentaries" movies={documentaries} />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Status Bar Simulation */}
      <div className="flex justify-between items-center px-4 py-1 text-white text-sm bg-black">
        <span>9:41</span>
        <div className="flex items-center space-x-1">
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-white rounded-full"></div>
            <div className="w-1 h-1 bg-gray-500 rounded-full"></div>
          </div>
          <div className="w-6 h-3 border border-white rounded-sm">
            <div className="w-4 h-full bg-white rounded-sm"></div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="flex items-center justify-between p-4 bg-black border-b border-gray-800">
        <h1 className="text-red-600 text-xl font-bold">SAHAN FILMS™</h1>
        <div className="flex items-center space-x-4">
          <button className="text-white">
            <TvIcon className="w-6 h-6" />
          </button>
          <button className="text-white">
            <Cog6ToothIcon className="w-6 h-6" />
          </button>
          <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
            <UserCircleIcon className="w-6 h-6 text-white" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      {renderContent()}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 px-4 py-2">
        <div className="flex justify-around">
          {[
            { id: 'home', label: 'Home', icon: HomeIcon, iconSolid: HomeIconSolid },
            { id: 'films', label: 'Films', icon: FilmIcon, iconSolid: FilmIconSolid },
            { id: 'subscriptions', label: 'Subscriptions', icon: CreditCardIcon, iconSolid: CreditCardIconSolid },
            { id: 'downloads', label: 'Downloads', icon: ArrowDownTrayIcon, iconSolid: ArrowDownTrayIconSolid },
            { id: 'search', label: 'Search', icon: MagnifyingGlassIcon, iconSolid: MagnifyingGlassIconSolid }
          ].map((item) => {
            const Icon = activeNav === item.id ? item.iconSolid : item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveNav(item.id as NavType)}
                className={`flex flex-col items-center py-2 px-3 ${
                  activeNav === item.id ? 'text-red-600' : 'text-gray-400'
                }`}
              >
                <Icon className="w-6 h-6 mb-1" />
                <span className="text-xs">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
