import { ArrowLeftIcon, UserCircleIcon } from "@heroicons/react/24/outline";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignOutButton } from "../SignOutButton";

interface AccountProps {
  onBack: () => void;
}

export default function Account({ onBack }: AccountProps) {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const userProfile = useQuery(api.auth.getUserProfile);

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Account Settings</h1>
        
        <div className="grid md:grid-cols-2 gap-8">
          <section className="bg-gray-900 p-6 rounded-lg">
            <div className="flex items-center space-x-4 mb-6">
              <UserCircleIcon className="w-16 h-16 text-gray-400" />
              <div>
                <h2 className="text-2xl font-semibold">Profile Information</h2>
                <p className="text-gray-400">Manage your account details</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-1">Display Name</label>
                <p className="text-white text-lg">{userProfile?.displayName || "Not set"}</p>
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Email</label>
                <p className="text-white text-lg">{loggedInUser?.email || "Not available"}</p>
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Full Name</label>
                <p className="text-white text-lg">
                  {userProfile ? `${userProfile.firstName} ${userProfile.lastName}` : "Not set"}
                </p>
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Date of Birth</label>
                <p className="text-white text-lg">{userProfile?.dateOfBirth || "Not set"}</p>
              </div>
            </div>
            
            <button className="mt-6 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded transition-colors">
              Edit Profile
            </button>
          </section>

          <section className="bg-gray-900 p-6 rounded-lg">
            <h2 className="text-2xl font-semibold mb-6">Subscription</h2>
            <div className="space-y-4">
              <div className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Current Plan</h3>
                <p className="text-gray-300">Premium Plan</p>
                <p className="text-sm text-gray-400">$12.99/month</p>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Next Billing Date</h3>
                <p className="text-gray-300">January 15, 2025</p>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Payment Method</h3>
                <p className="text-gray-300">•••• •••• •••• 1234</p>
              </div>
            </div>
            
            <div className="mt-6 space-y-2">
              <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded transition-colors">
                Change Plan
              </button>
              <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded transition-colors">
                Update Payment Method
              </button>
              <button className="w-full bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded transition-colors">
                Cancel Subscription
              </button>
            </div>
          </section>
        </div>

        <section className="mt-8 bg-gray-900 p-6 rounded-lg">
          <h2 className="text-2xl font-semibold mb-6">Privacy & Security</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Privacy Settings</h3>
              <div className="space-y-3">
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-gray-300">Allow personalized recommendations</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-gray-300">Share viewing history for better suggestions</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="rounded" />
                  <span className="text-gray-300">Receive marketing emails</span>
                </label>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Security</h3>
              <div className="space-y-2">
                <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded transition-colors text-left">
                  Change Password
                </button>
                <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded transition-colors text-left">
                  Two-Factor Authentication
                </button>
                <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded transition-colors text-left">
                  Download My Data
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-8 bg-gray-900 p-6 rounded-lg text-center">
          <h2 className="text-2xl font-semibold mb-4">Account Actions</h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SignOutButton />
            <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors">
              Delete Account
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
