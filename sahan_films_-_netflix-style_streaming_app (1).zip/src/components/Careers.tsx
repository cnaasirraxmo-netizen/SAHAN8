import { ArrowLeftIcon } from "@heroicons/react/24/outline";

interface CareersProps {
  onBack: () => void;
}

export default function Careers({ onBack }: CareersProps) {
  const jobOpenings = [
    {
      title: "Senior Frontend Developer",
      department: "Engineering",
      location: "Remote",
      type: "Full-time"
    },
    {
      title: "Content Curator",
      department: "Content",
      location: "Mogadishu, Somalia",
      type: "Full-time"
    },
    {
      title: "Marketing Manager",
      department: "Marketing",
      location: "Remote",
      type: "Full-time"
    },
    {
      title: "Film Acquisition Specialist",
      department: "Content",
      location: "Nairobi, Kenya",
      type: "Contract"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Join Our Team</h1>
        
        <div className="mb-12">
          <p className="text-xl text-gray-300 leading-relaxed mb-6">
            At SAHAN FILMS, we're building the future of entertainment. Join us in our mission to 
            bring authentic storytelling to audiences worldwide.
          </p>
          <p className="text-lg text-gray-300">
            We offer competitive salaries, comprehensive benefits, and the opportunity to work 
            with passionate people who are changing the entertainment industry.
          </p>
        </div>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Why Work With Us?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-3">Innovation</h3>
              <p className="text-gray-300">Work on cutting-edge technology and creative projects.</p>
            </div>
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-3">Impact</h3>
              <p className="text-gray-300">Help shape the future of global entertainment.</p>
            </div>
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-3">Growth</h3>
              <p className="text-gray-300">Continuous learning and career development opportunities.</p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-bold mb-6">Open Positions</h2>
          <div className="space-y-4">
            {jobOpenings.map((job, index) => (
              <div key={index} className="bg-gray-900 p-6 rounded-lg hover:bg-gray-800 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-semibold">{job.title}</h3>
                  <span className="bg-red-600 text-white px-3 py-1 rounded text-sm">{job.type}</span>
                </div>
                <div className="flex space-x-4 text-gray-300">
                  <span>{job.department}</span>
                  <span>•</span>
                  <span>{job.location}</span>
                </div>
                <button className="mt-4 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded transition-colors">
                  Apply Now
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-12 text-center">
          <h2 className="text-2xl font-bold mb-4">Don't see the right role?</h2>
          <p className="text-gray-300 mb-6">
            We're always looking for talented individuals. Send us your resume and we'll keep you in mind for future opportunities.
          </p>
          <button className="bg-gray-700 hover:bg-gray-600 text-white px-8 py-3 rounded-lg transition-colors">
            Send Resume
          </button>
        </section>
      </div>
    </div>
  );
}
