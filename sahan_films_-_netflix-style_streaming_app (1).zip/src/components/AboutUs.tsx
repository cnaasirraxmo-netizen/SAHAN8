import { ArrowLeftIcon } from "@heroicons/react/24/outline";

interface AboutUsProps {
  onBack: () => void;
}

export default function AboutUs({ onBack }: AboutUsProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">About SAHAN FILMS</h1>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Our Story</h2>
            <p className="text-lg">
              SAHAN FILMS was founded with a vision to bring the rich storytelling tradition of Somalia 
              to the global stage. We believe in the power of cinema to bridge cultures, share experiences, 
              and celebrate the diversity of human stories.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Our Mission</h2>
            <p className="text-lg">
              To provide a premier streaming platform that showcases authentic Somali cinema alongside 
              carefully curated international films. We are committed to supporting local filmmakers 
              and bringing their stories to audiences worldwide.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">What We Offer</h2>
            <ul className="text-lg space-y-2">
              <li>• Exclusive Somali films and documentaries</li>
              <li>• International cinema collection</li>
              <li>• Original content and productions</li>
              <li>• High-quality streaming experience</li>
              <li>• Multi-device accessibility</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Our Values</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Authenticity</h3>
                <p>We prioritize genuine storytelling that reflects real experiences and cultures.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Quality</h3>
                <p>Every film in our collection meets our high standards for production and storytelling.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Accessibility</h3>
                <p>We make great cinema available to everyone, everywhere.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Community</h3>
                <p>We support and celebrate the filmmaking community.</p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
