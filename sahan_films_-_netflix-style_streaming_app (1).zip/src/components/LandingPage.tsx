import { useState, useEffect } from "react";
import { ChevronDownIcon, PlayIcon } from "@heroicons/react/24/outline";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "What is SAHAN FILMS?",
    answer: "SAHAN FILMS is a streaming service that offers a wide variety of award-winning Somali movies, documentaries and more on thousands of internet-connected devices."
  },
  {
    question: "How much does SAHAN FILMS cost?",
    answer: "Watch SAHAN FILMS on your smartphone, tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee. Plans range from $8.99 to $17.99 a month."
  },
  {
    question: "Where can I watch?",
    answer: "Watch anywhere, anytime. Sign in with your SAHAN FILMS account to watch instantly on the web at sahanfilms.com from your personal computer or on any internet-connected device."
  },
  {
    question: "How do I cancel?",
    answer: "SAHAN FILMS is flexible. There are no pesky contracts and no commitments. You can easily cancel your account online in two clicks."
  },
  {
    question: "What can I watch on SAHAN FILMS?",
    answer: "SAHAN FILMS has an extensive library of feature films, documentaries, Somali cinema, international movies, and original content."
  }
];

interface LandingPageProps {
  onGetStarted: (email: string) => void;
  onNavigate: (page: string) => void;
}

export default function LandingPage({ onGetStarted, onNavigate }: LandingPageProps) {
  const [email, setEmail] = useState("");
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleGetStarted = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onGetStarted(email);
    }
  };

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Video/Image */}
        <div className="absolute inset-0 z-0">
          <div 
            className="w-full h-full bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')`
            }}
          />
        </div>

        {/* Navigation */}
        <nav className="absolute top-0 left-0 right-0 z-20 flex justify-between items-center p-6">
          <div className="text-red-600 text-3xl font-bold">SAHAN FILMS</div>
          <button className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-white font-semibold transition-colors">
            Sign In
          </button>
        </nav>

        {/* Hero Content */}
        <div className={`relative z-10 text-center max-w-4xl mx-auto px-6 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Unlimited movies and shows — anytime, anywhere.
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Ready to watch? Enter your email to get started.
          </p>
          
          <form onSubmit={handleGetStarted} className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 px-6 py-4 text-lg bg-white/10 backdrop-blur-sm border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-red-600"
              required
            />
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 px-8 py-4 text-lg font-semibold rounded transition-colors flex items-center justify-center gap-2"
            >
              Get Started
              <PlayIcon className="w-5 h-5" />
            </button>
          </form>
        </div>
      </section>

      {/* Feature Sections */}
      <section className="py-20">
        {/* Watch Anywhere */}
        <div className="max-w-6xl mx-auto px-6 mb-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className={`transition-all duration-1000 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">Watch everywhere.</h2>
              <p className="text-xl text-gray-300 leading-relaxed">
                Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV without paying more.
              </p>
            </div>
            <div className={`transition-all duration-1000 delay-400 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <img 
                src="https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Watch on multiple devices"
                className="w-full rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>

        {/* Download Section */}
        <div className="bg-gray-900 py-20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className={`order-2 md:order-1 transition-all duration-1000 delay-600 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
                <img 
                  src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Download and watch offline"
                  className="w-full rounded-lg shadow-2xl"
                />
              </div>
              <div className={`order-1 md:order-2 transition-all duration-1000 delay-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
                <h2 className="text-4xl md:text-5xl font-bold mb-6">Download your shows to watch offline.</h2>
                <p className="text-xl text-gray-300 leading-relaxed">
                  Save your favorites easily and always have something to watch.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Profiles Section */}
        <div className="py-20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className={`transition-all duration-1000 delay-1000 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
                <h2 className="text-4xl md:text-5xl font-bold mb-6">Create profiles for everyone.</h2>
                <p className="text-xl text-gray-300 leading-relaxed">
                  Send kids on adventures with their favorite characters in a space made just for them—free with your membership.
                </p>
              </div>
              <div className={`transition-all duration-1000 delay-1200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
                <img 
                  src="https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Multiple user profiles"
                  className="w-full rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-gray-900 py-20">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className={`text-4xl md:text-5xl font-bold text-center mb-12 transition-all duration-1000 delay-1400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-4">
            {faqData.map((faq, index) => (
              <div 
                key={index} 
                className={`bg-gray-800 rounded-lg transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${1600 + index * 100}ms` }}
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 py-6 text-left flex justify-between items-center hover:bg-gray-700 transition-colors rounded-lg"
                >
                  <span className="text-xl font-semibold">{faq.question}</span>
                  <ChevronDownIcon 
                    className={`w-6 h-6 transition-transform ${openFAQ === index ? 'rotate-180' : ''}`}
                  />
                </button>
                {openFAQ === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-300 text-lg leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-xl mb-6">Ready to watch? Enter your email to create or restart your membership.</p>
            <form onSubmit={handleGetStarted} className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-6 py-4 text-lg bg-white/10 backdrop-blur-sm border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-red-600"
                required
              />
              <button
                type="submit"
                className="bg-red-600 hover:bg-red-700 px-8 py-4 text-lg font-semibold rounded transition-colors flex items-center justify-center gap-2"
              >
                Get Started
                <PlayIcon className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-16">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-red-600 text-2xl font-bold mb-4">SAHAN FILMS</h3>
              <p className="text-gray-400">
                Your premier destination for Somali and international cinema.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button 
                    onClick={() => onNavigate('about')}
                    className="hover:text-white transition-colors text-left"
                  >
                    About Us
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('careers')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Careers
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('press')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Press
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button 
                    onClick={() => onNavigate('contact')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Contact
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('help')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Help Center
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('account')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Account
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button 
                    onClick={() => onNavigate('privacy')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('terms')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Terms of Service
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('cookies')}
                    className="hover:text-white transition-colors text-left"
                  >
                    Cookie Policy
                  </button>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SAHAN FILMS. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
