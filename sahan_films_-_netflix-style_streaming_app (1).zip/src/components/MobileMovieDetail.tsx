import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  PlayIcon, 
  PlusIcon, 
  ArrowDownTrayIcon, 
  StarIcon,
  HeartIcon,
  ShareIcon,
  XMarkIcon,
  ArrowLeftIcon
} from "@heroicons/react/24/outline";
import { StarIcon as StarIconSolid } from "@heroicons/react/24/solid";
import { Id } from "../../convex/_generated/dataModel";

interface MobileMovieDetailProps {
  movieId: Id<"movies">;
  onClose: () => void;
  onPlay: (movie: any) => void;
}

export default function MobileMovieDetail({ movieId, onClose, onPlay }: MobileMovieDetailProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'episodes' | 'trailers'>('overview');
  const [userRating, setUserRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [showReviewForm, setShowReviewForm] = useState(false);

  const movie = useQuery(api.movies.getMovieById, { movieId });
  const similarMovies = useQuery(api.movies.getMoviesByCategory, 
    movie ? { category: movie.category } : "skip"
  );
  const reviews = useQuery(api.movies.getMovieReviews, { movieId });
  const userReview = useQuery(api.movies.getUserReview, { movieId });
  
  const addToWatchlist = useMutation(api.movies.addToWatchlist);
  const submitReview = useMutation(api.movies.submitReview);
  const addToWatchHistory = useMutation(api.movies.addToWatchHistory);

  if (!movie) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  const handlePlay = () => {
    onPlay(movie);
    addToWatchHistory({ movieId, progress: 0 });
  };

  const handleAddToWatchlist = async () => {
    try {
      await addToWatchlist({ movieId });
    } catch (error) {
      console.error("Failed to add to watchlist:", error);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRating === 0 || !reviewText.trim()) return;
    
    try {
      await submitReview({
        movieId,
        rating: userRating,
        comment: reviewText.trim()
      });
      setReviewText("");
      setUserRating(0);
      setShowReviewForm(false);
    } catch (error) {
      console.error("Failed to submit review:", error);
    }
  };

  const filteredSimilarMovies = similarMovies?.filter(m => m._id !== movieId).slice(0, 6) || [];

  return (
    <div className="fixed inset-0 z-50 bg-black overflow-y-auto">
      {/* Hero Section */}
      <div className="relative h-80">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.8)), url(${movie.thumbnail})`
          }}
        />
        
        {/* Back Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 left-4 z-10 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
        >
          <ArrowLeftIcon className="w-6 h-6" />
        </button>

        {/* Movie Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h1 className="text-2xl font-bold mb-2">{movie.title}</h1>
          
          <div className="flex items-center space-x-3 mb-3">
            <div className="flex items-center space-x-1">
              {[...Array(5)].map((_, i) => (
                <StarIconSolid 
                  key={i} 
                  className={`w-4 h-4 ${i < Math.floor(movie.rating) ? 'text-yellow-500' : 'text-gray-600'}`} 
                />
              ))}
              <span className="ml-1 text-white text-sm font-semibold">{movie.rating}</span>
            </div>
            <span className="text-gray-300 text-sm">{movie.year}</span>
            <span className="text-gray-300 text-sm">{movie.duration}</span>
          </div>

          <div className="bg-gray-700 px-2 py-1 rounded text-xs inline-block mb-4">{movie.genre}</div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <button 
              onClick={handlePlay}
              className="bg-white text-black px-6 py-2 rounded-lg font-semibold flex items-center space-x-2 flex-1 justify-center"
            >
              <PlayIcon className="w-4 h-4" />
              <span>Play</span>
            </button>
            
            <button 
              onClick={handleAddToWatchlist}
              className="bg-gray-600/80 text-white p-2 rounded-lg"
            >
              <PlusIcon className="w-5 h-5" />
            </button>
            
            <button className="bg-gray-600/80 text-white p-2 rounded-lg">
              <ArrowDownTrayIcon className="w-5 h-5" />
            </button>
            
            <button className="bg-gray-600/80 text-white p-2 rounded-lg">
              <ShareIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <div className="px-4 py-4">
        {/* Tab Navigation */}
        <div className="flex space-x-6 mb-6 border-b border-gray-800">
          {[
            { id: 'overview', label: 'Overview' },
            { id: 'episodes', label: 'Episodes' },
            { id: 'trailers', label: 'Trailers' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 px-1 font-semibold transition-colors ${
                activeTab === tab.id 
                  ? 'text-white border-b-2 border-red-600' 
                  : 'text-gray-400'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold mb-3">Synopsis</h2>
              <p className="text-gray-300 leading-relaxed text-sm">{movie.description}</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Details</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Genre:</span>
                  <span className="text-white">{movie.genre}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Year:</span>
                  <span className="text-white">{movie.year}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Duration:</span>
                  <span className="text-white">{movie.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Rating:</span>
                  <span className="text-white">{movie.rating}/5</span>
                </div>
              </div>
            </div>

            {/* Reviews Section */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Reviews</h3>
                {!userReview && (
                  <button 
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm"
                  >
                    Write Review
                  </button>
                )}
              </div>

              {/* Review Form */}
              {showReviewForm && (
                <div className="bg-gray-900 p-4 rounded-lg mb-4">
                  <form onSubmit={handleSubmitReview}>
                    <div className="mb-3">
                      <label className="block text-white font-semibold mb-2 text-sm">Your Rating</label>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setUserRating(star)}
                            className="focus:outline-none"
                          >
                            <StarIcon 
                              className={`w-6 h-6 ${star <= userRating ? 'text-yellow-500 fill-current' : 'text-gray-600'}`} 
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <label className="block text-white font-semibold mb-2 text-sm">Your Review</label>
                      <textarea
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        placeholder="Share your thoughts..."
                        rows={3}
                        className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:border-red-600 focus:outline-none text-sm"
                        required
                      />
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        type="submit"
                        disabled={userRating === 0 || !reviewText.trim()}
                        className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white px-4 py-2 rounded text-sm"
                      >
                        Submit
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded text-sm"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Reviews List */}
              <div className="space-y-3">
                {reviews?.slice(0, 3).map((review) => (
                  <div key={review._id} className="bg-gray-900 p-3 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-semibold">
                            {review.userName?.charAt(0).toUpperCase() || 'U'}
                          </span>
                        </div>
                        <span className="text-white text-sm font-medium">{review.userName || 'Anonymous'}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <StarIconSolid 
                            key={i} 
                            className={`w-3 h-3 ${i < review.rating ? 'text-yellow-500' : 'text-gray-600'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm">{review.comment}</p>
                  </div>
                )) || []}
                
                {(!reviews || reviews.length === 0) && (
                  <div className="text-center py-6 text-gray-500 text-sm">
                    No reviews yet. Be the first to review!
                  </div>
                )}
              </div>
            </div>

            {/* Similar Movies */}
            {filteredSimilarMovies.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3">More Like This</h3>
                <div className="grid grid-cols-3 gap-3">
                  {filteredSimilarMovies.map((similarMovie) => (
                    <div 
                      key={similarMovie._id}
                      className="cursor-pointer"
                    >
                      <img 
                        src={similarMovie.thumbnail} 
                        alt={similarMovie.title}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <h4 className="text-white text-xs font-medium mt-1 line-clamp-2">{similarMovie.title}</h4>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'episodes' && (
          <div className="text-center py-12 text-gray-500">
            <p>No episodes available for this movie.</p>
          </div>
        )}

        {activeTab === 'trailers' && (
          <div className="text-center py-12 text-gray-500">
            <p>No trailers available.</p>
          </div>
        )}
      </div>
    </div>
  );
}
