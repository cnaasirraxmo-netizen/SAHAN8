import { ArrowLeftIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { useState } from "react";

interface HelpCenterProps {
  onBack: () => void;
}

export default function HelpCenter({ onBack }: HelpCenterProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { id: "all", name: "All Topics" },
    { id: "account", name: "Account & Billing" },
    { id: "streaming", name: "Streaming & Playback" },
    { id: "technical", name: "Technical Issues" },
    { id: "content", name: "Content & Features" }
  ];

  const faqs = [
    {
      category: "account",
      question: "How do I create an account?",
      answer: "Click 'Get Started' on our homepage, enter your email, and follow the sign-up process. You can also sign in anonymously to explore our content."
    },
    {
      category: "account",
      question: "How do I cancel my subscription?",
      answer: "Go to your account settings, select 'Subscription', and click 'Cancel Subscription'. Your access will continue until the end of your billing period."
    },
    {
      category: "streaming",
      question: "Why is my video buffering?",
      answer: "Buffering can be caused by slow internet connection. Try refreshing the page, checking your internet speed, or lowering the video quality in settings."
    },
    {
      category: "streaming",
      question: "What devices can I watch on?",
      answer: "SAHAN FILMS works on computers, smartphones, tablets, smart TVs, and streaming devices. Just visit our website or download our app."
    },
    {
      category: "technical",
      question: "The video won't play. What should I do?",
      answer: "Try refreshing the page, clearing your browser cache, or switching to a different browser. If the issue persists, contact our support team."
    },
    {
      category: "content",
      question: "How often is new content added?",
      answer: "We add new movies and shows regularly. Check our 'New Releases' section or follow us on social media for updates."
    }
  ];

  const filteredFaqs = faqs.filter(faq => {
    const matchesCategory = selectedCategory === "all" || faq.category === selectedCategory;
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Help Center</h1>
        
        <div className="mb-8">
          <div className="relative mb-6">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search for help..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedCategory === category.id
                    ? "bg-red-600 text-white"
                    : "bg-gray-800 text-gray-300 hover:bg-gray-700"
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <div key={index} className="bg-gray-900 rounded-lg">
                <details className="group">
                  <summary className="p-6 cursor-pointer hover:bg-gray-800 rounded-lg transition-colors">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold">{faq.question}</h3>
                      <span className="text-gray-400 group-open:rotate-180 transition-transform">▼</span>
                    </div>
                  </summary>
                  <div className="px-6 pb-6">
                    <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                  </div>
                </details>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-gray-900 p-8 rounded-lg text-center">
          <h2 className="text-2xl font-semibold mb-4">Still Need Help?</h2>
          <p className="text-gray-300 mb-6">
            Can't find what you're looking for? Our support team is here to help 24/7.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors">
              Contact Support
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors">
              Live Chat
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
