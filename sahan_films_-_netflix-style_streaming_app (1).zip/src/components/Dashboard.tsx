import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { MagnifyingGlassIcon, PlayIcon, UserCircleIcon } from "@heroicons/react/24/outline";
import { SignOutButton } from "../SignOutButton";
import MovieDetail from "./MovieDetail";
import VideoPlayer from "./VideoPlayer";
import { Id } from "../../convex/_generated/dataModel";

interface Movie {
  _id: Id<"movies">;
  title: string;
  description: string;
  genre: string;
  thumbnail: string;
  videoUrl: string;
  rating: number;
  year: number;
  duration: string;
  category: string;
  featured?: boolean;
}

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [showMovieDetail, setShowMovieDetail] = useState(false);
  const [playingMovie, setPlayingMovie] = useState<Movie | null>(null);
  
  const featuredMovie = useQuery(api.movies.getFeaturedMovie);
  const trendingMovies = useQuery(api.movies.getMoviesByCategory, { category: "trending" });
  const actionMovies = useQuery(api.movies.getMoviesByCategory, { category: "action" });
  const somaliMovies = useQuery(api.movies.getMoviesByCategory, { category: "somali" });
  const documentaries = useQuery(api.movies.getMoviesByCategory, { category: "documentary" });
  const searchResults = useQuery(api.movies.searchMovies, searchTerm ? { searchTerm } : "skip");

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setShowMovieDetail(true);
  };

  const handlePlayMovie = (movie: Movie) => {
    setPlayingMovie(movie);
    setShowMovieDetail(false);
  };

  const handleCloseDetail = () => {
    setShowMovieDetail(false);
    setSelectedMovie(null);
  };

  const handleClosePlayer = () => {
    setPlayingMovie(null);
  };

  const MovieCard = ({ movie }: { movie: Movie }) => (
    <div 
      className="relative group cursor-pointer transform transition-all duration-300 hover:scale-105"
      onClick={() => handleMovieClick(movie)}
    >
      <img 
        src={movie.thumbnail} 
        alt={movie.title}
        className="w-full h-40 object-cover rounded-lg"
      />
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 rounded-lg flex items-center justify-center">
        <PlayIcon className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent rounded-b-lg">
        <h3 className="text-white font-semibold text-sm">{movie.title}</h3>
        <p className="text-gray-300 text-xs">{movie.year} • {movie.duration}</p>
      </div>
    </div>
  );

  const MovieRow = ({ title, movies }: { title: string; movies: Movie[] | undefined }) => {
    if (!movies || movies.length === 0) return null;
    
    return (
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {movies.map((movie) => (
            <MovieCard key={movie._id} movie={movie} />
          ))}
        </div>
      </div>
    );
  };

  // Show video player if a movie is playing
  if (playingMovie) {
    return (
      <VideoPlayer 
        movie={playingMovie} 
        onClose={handleClosePlayer}
      />
    );
  }

  // Show movie detail if selected
  if (showMovieDetail && selectedMovie) {
    return (
      <MovieDetail 
        movieId={selectedMovie._id}
        onClose={handleCloseDetail}
        onPlay={handlePlayMovie}
      />
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-8">
            <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="hover:text-gray-300 transition-colors">Home</a>
              <a href="#" className="hover:text-gray-300 transition-colors">Movies</a>
              <a href="#" className="hover:text-gray-300 transition-colors">TV Shows</a>
              <a href="#" className="hover:text-gray-300 transition-colors">My List</a>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search movies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-gray-800 text-white pl-10 pr-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
              />
            </div>
            <UserCircleIcon className="w-8 h-8 text-white" />
            <SignOutButton />
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      {featuredMovie && (
        <section className="relative h-screen flex items-center">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.8)), url(${featuredMovie.thumbnail})`
            }}
          />
          <div className="relative z-10 max-w-2xl ml-8 md:ml-16">
            <h1 className="text-5xl md:text-7xl font-bold mb-4">{featuredMovie.title}</h1>
            <p className="text-lg md:text-xl mb-6 text-gray-300 leading-relaxed">
              {featuredMovie.description}
            </p>
            <div className="flex items-center space-x-4 mb-6">
              <span className="bg-yellow-500 text-black px-2 py-1 rounded font-bold">
                ★ {featuredMovie.rating}
              </span>
              <span className="text-gray-300">{featuredMovie.year}</span>
              <span className="text-gray-300">{featuredMovie.duration}</span>
            </div>
            <div className="flex space-x-4">
              <button 
                onClick={() => handlePlayMovie(featuredMovie)}
                className="bg-white text-black px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 hover:bg-gray-200 transition-colors"
              >
                <PlayIcon className="w-5 h-5" />
                <span>Play</span>
              </button>
              <button 
                onClick={() => handleMovieClick(featuredMovie)}
                className="bg-gray-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-500 transition-colors"
              >
                More Info
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Content Rows */}
      <div className="px-8 md:px-16 py-8 space-y-8">
        {searchTerm && searchResults ? (
          <MovieRow title="Search Results" movies={searchResults} />
        ) : (
          <>
            <MovieRow title="Trending Now" movies={trendingMovies} />
            <MovieRow title="Action Movies" movies={actionMovies} />
            <MovieRow title="Somali Cinema" movies={somaliMovies} />
            <MovieRow title="Documentaries" movies={documentaries} />
          </>
        )}
      </div>
    </div>
  );
}
