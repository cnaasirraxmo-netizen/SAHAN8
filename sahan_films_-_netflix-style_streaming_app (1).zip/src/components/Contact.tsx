import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import { toast } from "sonner";

interface ContactProps {
  onBack: () => void;
}

export default function Contact({ onBack }: ContactProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Message sent successfully! We'll get back to you soon.");
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Contact Us</h1>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-semibold mb-6">Get in Touch</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={formData.name}
                onChange={handleChange}
                className="auth-input-field"
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={handleChange}
                className="auth-input-field"
                required
              />
              <select
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                className="auth-input-field"
                required
              >
                <option value="">Select Subject</option>
                <option value="general">General Inquiry</option>
                <option value="technical">Technical Support</option>
                <option value="billing">Billing Question</option>
                <option value="content">Content Suggestion</option>
                <option value="partnership">Partnership</option>
              </select>
              <textarea
                name="message"
                placeholder="Your Message"
                value={formData.message}
                onChange={handleChange}
                rows={6}
                className="auth-input-field resize-none"
                required
              />
              <button
                type="submit"
                className="auth-button"
              >
                Send Message
              </button>
            </form>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-6">Contact Information</h2>
            <div className="space-y-6">
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Customer Support</h3>
                <p className="text-gray-300 mb-2">support@sahanfilms.com</p>
                <p className="text-gray-300">Available 24/7</p>
              </div>
              
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Business Inquiries</h3>
                <p className="text-gray-300 mb-2">business@sahanfilms.com</p>
                <p className="text-gray-300">+1 (555) 123-4567</p>
              </div>
              
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Headquarters</h3>
                <p className="text-gray-300">
                  123 Entertainment Blvd<br />
                  Los Angeles, CA 90028<br />
                  United States
                </p>
              </div>
              
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Regional Office</h3>
                <p className="text-gray-300">
                  Mogadishu Business Center<br />
                  Mogadishu, Somalia<br />
                  East Africa
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
