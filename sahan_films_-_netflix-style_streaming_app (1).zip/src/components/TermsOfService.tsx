import { ArrowLeftIcon } from "@heroicons/react/24/outline";

interface TermsOfServiceProps {
  onBack: () => void;
}

export default function TermsOfService({ onBack }: TermsOfServiceProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Terms of Service</h1>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <p className="text-sm text-gray-400 mb-4">Last updated: December 15, 2024</p>
            <p className="text-lg">
              Welcome to SAHAN FILMS. These Terms of Service govern your use of our streaming platform 
              and services. By using our service, you agree to these terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">1. Service Description</h2>
            <p>
              SAHAN FILMS provides a subscription-based streaming service that allows you to access 
              and view movies, documentaries, and other video content on internet-connected devices.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">2. Eligibility</h2>
            <p>
              You must be at least 18 years old to create an account. If you are under 18, 
              you may use the service only with parental consent and supervision.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">3. Account Registration</h2>
            <ul className="space-y-2">
              <li>• You must provide accurate and complete information</li>
              <li>• You are responsible for maintaining account security</li>
              <li>• You may not share your account credentials</li>
              <li>• One account per person</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">4. Subscription and Billing</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Subscription Plans</h3>
                <p>We offer various subscription plans with different features and pricing.</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Billing</h3>
                <p>Subscriptions are billed in advance on a monthly or annual basis.</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Cancellation</h3>
                <p>You may cancel your subscription at any time. Access continues until the end of your billing period.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">5. Acceptable Use</h2>
            <p className="mb-4">You agree not to:</p>
            <ul className="space-y-2">
              <li>• Use the service for any illegal purpose</li>
              <li>• Share or distribute content without permission</li>
              <li>• Attempt to circumvent security measures</li>
              <li>• Use automated systems to access the service</li>
              <li>• Interfere with other users' enjoyment of the service</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">6. Content and Intellectual Property</h2>
            <p>
              All content on SAHAN FILMS is protected by copyright and other intellectual property laws. 
              You may not copy, distribute, or create derivative works from our content.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">7. Privacy</h2>
            <p>
              Your privacy is important to us. Please review our Privacy Policy to understand 
              how we collect and use your information.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">8. Disclaimers</h2>
            <p>
              The service is provided "as is" without warranties of any kind. We do not guarantee 
              uninterrupted or error-free service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">9. Limitation of Liability</h2>
            <p>
              SAHAN FILMS shall not be liable for any indirect, incidental, special, or consequential 
              damages arising from your use of the service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">10. Termination</h2>
            <p>
              We may terminate or suspend your account at any time for violation of these terms 
              or for any other reason at our discretion.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">11. Changes to Terms</h2>
            <p>
              We may update these terms from time to time. We will notify you of significant 
              changes via email or through the service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">12. Contact Information</h2>
            <p>
              If you have questions about these terms, please contact us at legal@sahanfilms.com.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
