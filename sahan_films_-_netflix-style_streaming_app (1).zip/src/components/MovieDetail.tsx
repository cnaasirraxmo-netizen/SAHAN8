import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  PlayIcon, 
  PlusIcon, 
  ArrowDownTrayIcon, 
  StarIcon,
  HeartIcon,
  ShareIcon,
  XMarkIcon,
  ChevronLeftIcon,
  ChevronRightIcon
} from "@heroicons/react/24/outline";
import { StarIcon as StarIconSolid } from "@heroicons/react/24/solid";
import { Id } from "../../convex/_generated/dataModel";

interface MovieDetailProps {
  movieId: Id<"movies">;
  onClose: () => void;
  onPlay: (movie: any) => void;
}

export default function MovieDetail({ movieId, onClose, onPlay }: MovieDetailProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews' | 'similar'>('overview');
  const [userRating, setUserRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [showReviewForm, setShowReviewForm] = useState(false);

  const movie = useQuery(api.movies.getMovieById, { movieId });
  const similarMovies = useQuery(api.movies.getMoviesByCategory, 
    movie ? { category: movie.category } : "skip"
  );
  const reviews = useQuery(api.movies.getMovieReviews, { movieId });
  const userReview = useQuery(api.movies.getUserReview, { movieId });
  
  const addToWatchlist = useMutation(api.movies.addToWatchlist);
  const submitReview = useMutation(api.movies.submitReview);
  const addToWatchHistory = useMutation(api.movies.addToWatchHistory);

  if (!movie) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  const handlePlay = () => {
    onPlay(movie);
    addToWatchHistory({ movieId, progress: 0 });
  };

  const handleAddToWatchlist = async () => {
    try {
      await addToWatchlist({ movieId });
    } catch (error) {
      console.error("Failed to add to watchlist:", error);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRating === 0 || !reviewText.trim()) return;
    
    try {
      await submitReview({
        movieId,
        rating: userRating,
        comment: reviewText.trim()
      });
      setReviewText("");
      setUserRating(0);
      setShowReviewForm(false);
    } catch (error) {
      console.error("Failed to submit review:", error);
    }
  };

  const filteredSimilarMovies = similarMovies?.filter(m => m._id !== movieId).slice(0, 6) || [];

  return (
    <div className="fixed inset-0 z-50 bg-black overflow-y-auto">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.8)), url(${movie.thumbnail})`
          }}
        />
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
        >
          <XMarkIcon className="w-6 h-6" />
        </button>

        {/* Movie Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">{movie.title}</h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <StarIconSolid 
                    key={i} 
                    className={`w-5 h-5 ${i < Math.floor(movie.rating) ? 'text-yellow-500' : 'text-gray-600'}`} 
                  />
                ))}
                <span className="ml-2 text-white font-semibold">{movie.rating}</span>
              </div>
              <span className="text-gray-300">{movie.year}</span>
              <span className="text-gray-300">{movie.duration}</span>
              <span className="bg-gray-700 px-2 py-1 rounded text-sm">{movie.genre}</span>
            </div>

            <p className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed max-w-3xl">
              {movie.description}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={handlePlay}
                className="bg-white text-black px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 hover:bg-gray-200 transition-colors"
              >
                <PlayIcon className="w-5 h-5" />
                <span>Play</span>
              </button>
              
              <button 
                onClick={handleAddToWatchlist}
                className="bg-gray-600/80 text-white px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 hover:bg-gray-500/80 transition-colors"
              >
                <PlusIcon className="w-5 h-5" />
                <span>My List</span>
              </button>
              
              <button className="bg-gray-600/80 text-white px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 hover:bg-gray-500/80 transition-colors">
                <ArrowDownTrayIcon className="w-5 h-5" />
                <span>Download</span>
              </button>
              
              <button className="bg-gray-600/80 text-white p-3 rounded-lg hover:bg-gray-500/80 transition-colors">
                <ShareIcon className="w-5 h-5" />
              </button>
              
              <button className="bg-gray-600/80 text-white p-3 rounded-lg hover:bg-gray-500/80 transition-colors">
                <HeartIcon className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <div className="bg-black px-8 md:px-16 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Tab Navigation */}
          <div className="flex space-x-8 mb-8 border-b border-gray-800">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'reviews', label: 'Reviews' },
              { id: 'similar', label: 'More Like This' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`pb-4 px-2 font-semibold transition-colors ${
                  activeTab === tab.id 
                    ? 'text-white border-b-2 border-red-600' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === 'overview' && (
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <h2 className="text-2xl font-bold mb-4">Synopsis</h2>
                <p className="text-gray-300 leading-relaxed mb-6">{movie.description}</p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Details</h3>
                    <div className="space-y-2 text-gray-300">
                      <div><span className="text-white">Genre:</span> {movie.genre}</div>
                      <div><span className="text-white">Year:</span> {movie.year}</div>
                      <div><span className="text-white">Duration:</span> {movie.duration}</div>
                      <div><span className="text-white">Rating:</span> {movie.rating}/5</div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Cast & Crew</h3>
                    <div className="space-y-2 text-gray-300">
                      <div><span className="text-white">Director:</span> Ahmed Hassan</div>
                      <div><span className="text-white">Producer:</span> Fatima Ali</div>
                      <div><span className="text-white">Starring:</span> Omar Mohamed, Amina Yusuf</div>
                      <div><span className="text-white">Music:</span> Khalid Ibrahim</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <img 
                  src={movie.thumbnail} 
                  alt={movie.title}
                  className="w-full rounded-lg mb-4"
                />
                <div className="bg-gray-900 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Available in</h3>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-gray-700 px-2 py-1 rounded text-sm">4K Ultra HD</span>
                    <span className="bg-gray-700 px-2 py-1 rounded text-sm">HDR</span>
                    <span className="bg-gray-700 px-2 py-1 rounded text-sm">Dolby Atmos</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="max-w-4xl">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Reviews & Ratings</h2>
                {!userReview && (
                  <button 
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    Write Review
                  </button>
                )}
              </div>

              {/* Review Form */}
              {showReviewForm && (
                <div className="bg-gray-900 p-6 rounded-lg mb-6">
                  <form onSubmit={handleSubmitReview}>
                    <div className="mb-4">
                      <label className="block text-white font-semibold mb-2">Your Rating</label>
                      <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setUserRating(star)}
                            className="focus:outline-none"
                          >
                            <StarIcon 
                              className={`w-8 h-8 ${star <= userRating ? 'text-yellow-500 fill-current' : 'text-gray-600'}`} 
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-white font-semibold mb-2">Your Review</label>
                      <textarea
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        placeholder="Share your thoughts about this movie..."
                        rows={4}
                        className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:border-red-600 focus:outline-none"
                        required
                      />
                    </div>
                    
                    <div className="flex space-x-3">
                      <button
                        type="submit"
                        disabled={userRating === 0 || !reviewText.trim()}
                        className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
                      >
                        Submit Review
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* User's Review */}
              {userReview && (
                <div className="bg-gray-900 p-6 rounded-lg mb-6 border-l-4 border-red-600">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">Your Review</h3>
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <StarIconSolid 
                          key={i} 
                          className={`w-4 h-4 ${i < userReview.rating ? 'text-yellow-500' : 'text-gray-600'}`} 
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-300">{userReview.comment}</p>
                  <p className="text-gray-500 text-sm mt-2">
                    {new Date(userReview._creationTime).toLocaleDateString()}
                  </p>
                </div>
              )}

              {/* Other Reviews */}
              <div className="space-y-4">
                {reviews?.filter(review => review.userId !== userReview?.userId).map((review) => (
                  <div key={review._id} className="bg-gray-900 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold">
                            {review.userName?.charAt(0).toUpperCase() || 'U'}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-semibold">{review.userName || 'Anonymous'}</h4>
                          <div className="flex items-center space-x-1">
                            {[...Array(5)].map((_, i) => (
                              <StarIconSolid 
                                key={i} 
                                className={`w-4 h-4 ${i < review.rating ? 'text-yellow-500' : 'text-gray-600'}`} 
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      <span className="text-gray-500 text-sm">
                        {new Date(review._creationTime).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-300">{review.comment}</p>
                  </div>
                )) || []}
                
                {(!reviews || reviews.length === 0) && (
                  <div className="text-center py-8 text-gray-500">
                    No reviews yet. Be the first to review this movie!
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'similar' && (
            <div>
              <h2 className="text-2xl font-bold mb-6">More Like This</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {filteredSimilarMovies.map((similarMovie) => (
                  <div 
                    key={similarMovie._id}
                    className="group cursor-pointer transform transition-all duration-300 hover:scale-105"
                  >
                    <div className="relative">
                      <img 
                        src={similarMovie.thumbnail} 
                        alt={similarMovie.title}
                        className="w-full h-40 object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 rounded-lg flex items-center justify-center">
                        <PlayIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      </div>
                    </div>
                    <div className="mt-2">
                      <h3 className="text-white font-semibold text-sm truncate">{similarMovie.title}</h3>
                      <div className="flex items-center space-x-2 text-xs text-gray-400">
                        <span>{similarMovie.year}</span>
                        <span>•</span>
                        <div className="flex items-center space-x-1">
                          <StarIconSolid className="w-3 h-3 text-yellow-500" />
                          <span>{similarMovie.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {filteredSimilarMovies.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No similar movies found.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
