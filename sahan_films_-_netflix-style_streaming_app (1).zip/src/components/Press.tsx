import { ArrowLeftIcon } from "@heroicons/react/24/outline";

interface PressProps {
  onBack: () => void;
}

export default function Press({ onBack }: PressProps) {
  const pressReleases = [
    {
      date: "December 15, 2024",
      title: "SAHAN FILMS Launches Revolutionary Streaming Platform for Somali Cinema",
      excerpt: "New platform brings authentic Somali storytelling to global audiences with innovative features and exclusive content."
    },
    {
      date: "November 28, 2024",
      title: "SAHAN FILMS Partners with Leading African Film Festivals",
      excerpt: "Strategic partnerships announced to showcase emerging talent and promote cultural exchange through cinema."
    },
    {
      date: "October 10, 2024",
      title: "SAHAN FILMS Receives $5M in Series A Funding",
      excerpt: "Investment will accelerate platform development and content acquisition across East Africa."
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Press Center</h1>
        
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">Latest News</h2>
          <div className="space-y-6">
            {pressReleases.map((release, index) => (
              <article key={index} className="bg-gray-900 p-6 rounded-lg">
                <div className="text-gray-400 text-sm mb-2">{release.date}</div>
                <h3 className="text-xl font-semibold mb-3">{release.title}</h3>
                <p className="text-gray-300 mb-4">{release.excerpt}</p>
                <button className="text-red-600 hover:text-red-500 font-medium">
                  Read Full Release →
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">Media Kit</h2>
          <div className="bg-gray-900 p-6 rounded-lg">
            <p className="text-gray-300 mb-6">
              Download our media kit for logos, brand guidelines, and high-resolution images.
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded transition-colors">
                Download Media Kit
              </button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded transition-colors">
                Brand Guidelines
              </button>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-6">Press Contacts</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Media Inquiries</h3>
              <p className="text-gray-300 mb-2">press@sahanfilms.com</p>
              <p className="text-gray-300">+1 (555) 123-4567</p>
            </div>
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Partnership Inquiries</h3>
              <p className="text-gray-300 mb-2">partnerships@sahanfilms.com</p>
              <p className="text-gray-300">+1 (555) 123-4568</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
