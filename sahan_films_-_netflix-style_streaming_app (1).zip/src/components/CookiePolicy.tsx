import { ArrowLeftIcon } from "@heroicons/react/24/outline";

interface CookiePolicyProps {
  onBack: () => void;
}

export default function CookiePolicy({ onBack }: CookiePolicyProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="text-red-600 text-2xl font-bold">SAHAN FILMS</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Cookie Policy</h1>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <p className="text-sm text-gray-400 mb-4">Last updated: December 15, 2024</p>
            <p className="text-lg">
              This Cookie Policy explains how SAHAN FILMS uses cookies and similar technologies 
              to recognize you when you visit our platform.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">What are Cookies?</h2>
            <p>
              Cookies are small data files that are placed on your computer or mobile device when you 
              visit a website. They are widely used to make websites work more efficiently and provide 
              information to website owners.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Types of Cookies We Use</h2>
            <div className="space-y-6">
              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-3">Essential Cookies</h3>
                <p className="mb-2">These cookies are necessary for the website to function properly.</p>
                <ul className="space-y-1 text-sm">
                  <li>• Authentication and security</li>
                  <li>• Session management</li>
                  <li>• Load balancing</li>
                </ul>
              </div>

              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-3">Performance Cookies</h3>
                <p className="mb-2">These cookies help us understand how visitors interact with our website.</p>
                <ul className="space-y-1 text-sm">
                  <li>• Page views and navigation patterns</li>
                  <li>• Error tracking</li>
                  <li>• Performance monitoring</li>
                </ul>
              </div>

              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-3">Functional Cookies</h3>
                <p className="mb-2">These cookies enable enhanced functionality and personalization.</p>
                <ul className="space-y-1 text-sm">
                  <li>• Language preferences</li>
                  <li>• Video quality settings</li>
                  <li>• User interface preferences</li>
                </ul>
              </div>

              <div className="bg-gray-900 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-3">Targeting Cookies</h3>
                <p className="mb-2">These cookies are used to deliver personalized content and advertisements.</p>
                <ul className="space-y-1 text-sm">
                  <li>• Content recommendations</li>
                  <li>• Personalized marketing</li>
                  <li>• Social media integration</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Third-Party Cookies</h2>
            <p className="mb-4">We may also use third-party cookies from:</p>
            <ul className="space-y-2">
              <li>• Analytics providers (Google Analytics)</li>
              <li>• Content delivery networks</li>
              <li>• Social media platforms</li>
              <li>• Payment processors</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Managing Cookies</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Browser Settings</h3>
                <p>You can control cookies through your browser settings. Most browsers allow you to:</p>
                <ul className="space-y-1 mt-2">
                  <li>• View cookies stored on your device</li>
                  <li>• Delete existing cookies</li>
                  <li>• Block cookies from specific sites</li>
                  <li>• Block all cookies</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Cookie Preferences</h3>
                <p>You can manage your cookie preferences through our cookie consent banner or by contacting us.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Impact of Disabling Cookies</h2>
            <p className="mb-4">If you disable cookies, some features of our service may not work properly:</p>
            <ul className="space-y-2">
              <li>• You may need to log in repeatedly</li>
              <li>• Personalized recommendations may not work</li>
              <li>• Some videos may not play correctly</li>
              <li>• Your preferences may not be saved</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Updates to This Policy</h2>
            <p>
              We may update this Cookie Policy from time to time. We will notify you of any 
              significant changes by posting the new policy on this page.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Contact Us</h2>
            <p>
              If you have questions about our use of cookies, please contact us at 
              privacy@sahanfilms.com.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
