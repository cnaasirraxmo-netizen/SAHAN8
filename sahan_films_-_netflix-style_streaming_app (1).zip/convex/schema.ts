import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  movies: defineTable({
    title: v.string(),
    description: v.string(),
    genre: v.string(),
    thumbnail: v.string(),
    videoUrl: v.string(),
    rating: v.number(),
    year: v.number(),
    duration: v.string(),
    featured: v.optional(v.boolean()),
    category: v.string(),
  })
    .index("by_genre", ["genre"])
    .index("by_category", ["category"])
    .index("by_featured", ["featured"]),

  watchHistory: defineTable({
    userId: v.id("users"),
    movieId: v.id("movies"),
    watchedAt: v.number(),
    progress: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_movie", ["movieId"]),

  watchlist: defineTable({
    userId: v.id("users"),
    movieId: v.id("movies"),
    addedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_movie", ["movieId"])
    .index("by_user_movie", ["userId", "movieId"]),

  reviews: defineTable({
    userId: v.id("users"),
    movieId: v.id("movies"),
    rating: v.number(),
    comment: v.string(),
    userName: v.string(),
  })
    .index("by_user", ["userId"])
    .index("by_movie", ["movieId"])
    .index("by_user_movie", ["userId", "movieId"]),

  profiles: defineTable({
    userId: v.id("users"),
    name: v.string(),
    avatar: v.string(),
    isMain: v.boolean(),
  }).index("by_user", ["userId"]),

  userProfiles: defineTable({
    userId: v.id("users"),
    firstName: v.string(),
    lastName: v.string(),
    dateOfBirth: v.string(),
    displayName: v.string(),
    preferences: v.optional(v.object({
      favoriteGenres: v.array(v.string()),
      language: v.string(),
    })),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
