import { mutation } from "./_generated/server";

export const initializeSampleMovies = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if movies already exist
    const existingMovies = await ctx.db.query("movies").first();
    if (existingMovies) {
      return "Movies already exist";
    }

    const sampleMovies = [
      {
        title: "Baraf",
        description: "A gripping Somali drama about family, tradition, and modern challenges in contemporary Somalia.",
        genre: "Drama",
        thumbnail: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/baraf",
        rating: 8.5,
        year: 2023,
        duration: "2h 15m",
        category: "somali",
        featured: true,
      },
      {
        title: "The Nomad's Journey",
        description: "An epic tale following a Somali nomad's journey across the Horn of Africa.",
        genre: "Adventure",
        thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/nomad",
        rating: 7.8,
        year: 2022,
        duration: "1h 58m",
        category: "trending",
      },
      {
        title: "Mogadishu Rising",
        description: "A powerful documentary about the resilience and rebuilding of Somalia's capital city.",
        genre: "Documentary",
        thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/mogadishu",
        rating: 9.1,
        year: 2023,
        duration: "1h 32m",
        category: "documentary",
      },
      {
        title: "Desert Storm",
        description: "An action-packed thriller set in the Somali desert with international intrigue.",
        genre: "Action",
        thumbnail: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/desert-storm",
        rating: 7.2,
        year: 2023,
        duration: "2h 5m",
        category: "action",
      },
      {
        title: "Camel Caravan",
        description: "A beautiful story of traditional Somali traders crossing the desert with their camel caravans.",
        genre: "Adventure",
        thumbnail: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/camel-caravan",
        rating: 8.1,
        year: 2022,
        duration: "1h 45m",
        category: "somali",
      },
      {
        title: "Ocean's Call",
        description: "The story of Somali fishermen and their connection to the Indian Ocean.",
        genre: "Drama",
        thumbnail: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/oceans-call",
        rating: 7.9,
        year: 2023,
        duration: "2h 8m",
        category: "trending",
      },
      {
        title: "Horn of Africa",
        description: "An epic historical drama spanning generations in the Horn of Africa region.",
        genre: "Historical",
        thumbnail: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/horn-africa",
        rating: 8.7,
        year: 2023,
        duration: "2h 32m",
        category: "action",
      },
      {
        title: "Voices of Somalia",
        description: "A documentary exploring the rich oral traditions and poetry of Somali culture.",
        genre: "Documentary",
        thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        videoUrl: "https://example.com/voices-somalia",
        rating: 8.9,
        year: 2022,
        duration: "1h 28m",
        category: "documentary",
      },
    ];

    for (const movie of sampleMovies) {
      await ctx.db.insert("movies", movie);
    }

    return "Sample movies initialized successfully";
  },
});
