import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getUserPreferences = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }
    
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    
    return userProfile?.preferences || null;
  },
});

export const updateUserPreferences = mutation({
  args: {
    favoriteGenres: v.array(v.string()),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    
    if (!userProfile) {
      throw new Error("User profile not found");
    }
    
    await ctx.db.patch(userProfile._id, {
      preferences: {
        favoriteGenres: args.favoriteGenres,
        language: args.language,
      },
    });
    
    return { success: true };
  },
});

export const getRecommendedMovies = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    
    if (!userProfile?.preferences?.favoriteGenres) {
      // Return trending movies if no preferences
      return await ctx.db
        .query("movies")
        .order("desc")
        .take(10);
    }
    
    // Get movies from user's favorite genres
    const allMovies = await ctx.db.query("movies").collect();
    const recommendedMovies = allMovies.filter(movie => 
      userProfile.preferences!.favoriteGenres.includes(movie.genre)
    );
    
    return recommendedMovies.slice(0, 10);
  },
});
