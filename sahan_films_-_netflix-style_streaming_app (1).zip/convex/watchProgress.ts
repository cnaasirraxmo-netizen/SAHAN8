import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const updateWatchProgress = mutation({
  args: {
    movieId: v.id("movies"),
    progress: v.number(),
    currentTime: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    // Check if watch history entry exists
    const existingEntry = await ctx.db
      .query("watchHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("movieId"), args.movieId))
      .first();
    
    if (existingEntry) {
      // Update existing entry
      await ctx.db.patch(existingEntry._id, {
        progress: args.progress,
        watchedAt: Date.now(),
      });
    } else {
      // Create new entry
      await ctx.db.insert("watchHistory", {
        userId,
        movieId: args.movieId,
        progress: args.progress,
        watchedAt: Date.now(),
      });
    }
    
    return { success: true };
  },
});

export const getWatchProgress = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }
    
    const watchEntry = await ctx.db
      .query("watchHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("movieId"), args.movieId))
      .first();
    
    return watchEntry ? { progress: watchEntry.progress } : null;
  },
});

export const getContinueWatching = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    
    const watchHistory = await ctx.db
      .query("watchHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.gt(q.field("progress"), 0.05) && q.lt(q.field("progress"), 0.95))
      .order("desc")
      .take(10);
    
    // Get movie details for each watch history item
    const moviesWithProgress = await Promise.all(
      watchHistory.map(async (item) => {
        const movie = await ctx.db.get(item.movieId);
        return movie ? { ...movie, progress: item.progress, watchedAt: item.watchedAt } : null;
      })
    );
    
    return moviesWithProgress.filter(Boolean);
  },
});
