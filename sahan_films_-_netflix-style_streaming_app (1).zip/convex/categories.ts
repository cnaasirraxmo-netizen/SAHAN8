import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getAllCategories = query({
  args: {},
  handler: async (ctx) => {
    const movies = await ctx.db.query("movies").collect();
    const categories = [...new Set(movies.map(movie => movie.category))];
    return categories.filter(Boolean);
  },
});

export const getGenres = query({
  args: {},
  handler: async (ctx) => {
    const movies = await ctx.db.query("movies").collect();
    const genres = [...new Set(movies.map(movie => movie.genre))];
    return genres.filter(Boolean);
  },
});

export const getMoviesByGenre = query({
  args: { genre: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("movies")
      .withIndex("by_genre", (q) => q.eq("genre", args.genre))
      .collect();
  },
});

export const getTrendingMovies = query({
  args: {},
  handler: async (ctx) => {
    // Get movies with highest ratings or most recent
    return await ctx.db
      .query("movies")
      .order("desc")
      .take(20);
  },
});

export const getRecentlyAdded = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("movies")
      .order("desc")
      .take(10);
  },
});
