import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getFeaturedMovie = query({
  args: {},
  handler: async (ctx) => {
    const featured = await ctx.db
      .query("movies")
      .withIndex("by_featured", (q) => q.eq("featured", true))
      .first();
    
    if (featured) return featured;
    
    // If no featured movie, return the first movie
    return await ctx.db.query("movies").first();
  },
});

export const getMoviesByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("movies")
      .withIndex("by_category", (q) => q.eq("category", args.category))
      .collect();
  },
});

export const getAllMovies = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("movies").collect();
  },
});

export const getMovieById = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.movieId);
  },
});

export const searchMovies = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const movies = await ctx.db.query("movies").collect();
    return movies.filter(movie => 
      movie.title.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      movie.description.toLowerCase().includes(args.searchTerm.toLowerCase())
    );
  },
});

export const addMovie = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    genre: v.string(),
    thumbnail: v.string(),
    videoUrl: v.string(),
    rating: v.number(),
    year: v.number(),
    duration: v.string(),
    category: v.string(),
    featured: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    return await ctx.db.insert("movies", args);
  },
});

export const addToWatchHistory = mutation({
  args: {
    movieId: v.id("movies"),
    progress: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    return await ctx.db.insert("watchHistory", {
      userId,
      movieId: args.movieId,
      progress: args.progress,
      watchedAt: Date.now(),
    });
  },
});

export const getWatchHistory = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    
    return await ctx.db
      .query("watchHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const addToWatchlist = mutation({
  args: {
    movieId: v.id("movies"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    // Check if already in watchlist
    const existing = await ctx.db
      .query("watchlist")
      .withIndex("by_user_movie", (q) => 
        q.eq("userId", userId).eq("movieId", args.movieId)
      )
      .first();
    
    if (existing) {
      throw new Error("Movie already in watchlist");
    }
    
    return await ctx.db.insert("watchlist", {
      userId,
      movieId: args.movieId,
      addedAt: Date.now(),
    });
  },
});

export const getWatchlist = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    
    const watchlistItems = await ctx.db
      .query("watchlist")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
    
    // Get movie details for each watchlist item
    const movies = await Promise.all(
      watchlistItems.map(async (item) => {
        const movie = await ctx.db.get(item.movieId);
        return movie ? { ...movie, addedAt: item.addedAt } : null;
      })
    );
    
    return movies.filter(Boolean);
  },
});

export const removeFromWatchlist = mutation({
  args: {
    movieId: v.id("movies"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    const watchlistItem = await ctx.db
      .query("watchlist")
      .withIndex("by_user_movie", (q) => 
        q.eq("userId", userId).eq("movieId", args.movieId)
      )
      .first();
    
    if (watchlistItem) {
      await ctx.db.delete(watchlistItem._id);
    }
  },
});

export const submitReview = mutation({
  args: {
    movieId: v.id("movies"),
    rating: v.number(),
    comment: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    const user = await ctx.db.get(userId);
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    
    // Check if user already reviewed this movie
    const existingReview = await ctx.db
      .query("reviews")
      .withIndex("by_user_movie", (q) => 
        q.eq("userId", userId).eq("movieId", args.movieId)
      )
      .first();
    
    if (existingReview) {
      // Update existing review
      return await ctx.db.patch(existingReview._id, {
        rating: args.rating,
        comment: args.comment,
      });
    } else {
      // Create new review
      return await ctx.db.insert("reviews", {
        userId,
        movieId: args.movieId,
        rating: args.rating,
        comment: args.comment,
        userName: userProfile?.displayName || user?.name || "Anonymous",
      });
    }
  },
});

export const getMovieReviews = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("reviews")
      .withIndex("by_movie", (q) => q.eq("movieId", args.movieId))
      .order("desc")
      .collect();
  },
});

export const getUserReview = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }
    
    return await ctx.db
      .query("reviews")
      .withIndex("by_user_movie", (q) => 
        q.eq("userId", userId).eq("movieId", args.movieId)
      )
      .first();
  },
});
